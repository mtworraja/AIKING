import React from 'react'

const App = () => {
  return (
    <div className="text-center p-10">
      <h1 className="text-4xl font-bold text-purple-600">Welcome to AI KING</h1>
      <p className="mt-4 text-gray-600">by Mr. Raja</p>
    </div>
  )
}

export default App
